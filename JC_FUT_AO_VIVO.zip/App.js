
import React, { useState, useEffect } from 'react';
import { View, Text, Image, Button, FlatList } from 'react-native';
import ReactPlayer from 'react-player';
import axios from 'axios';

const App = () => {
  const [games, setGames] = useState([]);
  const [selectedGame, setSelectedGame] = useState(null);

  useEffect(() => {
    axios.get('https://<your-api-url>/games')
      .then(response => setGames(response.data))
      .catch(error => console.error('Erro ao carregar jogos:', error));
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: 'black', padding: 16 }}>
      <Text style={{ color: 'white', fontSize: 32, fontWeight: 'bold', marginBottom: 16 }}>JC FUT AO VIVO</Text>

      {selectedGame ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <Text style={{ color: 'white', fontSize: 24, marginBottom: 16 }}>Assistindo: {selectedGame.title}</Text>
          <ReactPlayer
            url={selectedGame.streamUrl}
            playing
            controls
            width='100%'
            height={300}
          />
          <Button title='Voltar' onPress={() => setSelectedGame(null)} />
        </View>
      ) : (
        <FlatList
          data={games}
          renderItem={({ item }) => (
            <View style={{ marginBottom: 16, borderBottomWidth: 1, borderBottomColor: 'white' }}>
              <Image
                source={{ uri: item.thumbnail }}
                style={{ width: '100%', height: 200 }}
              />
              <Text style={{ color: 'white', fontSize: 18, marginVertical: 8 }}>{item.title}</Text>
              {item.live && <Text style={{ color: 'red', fontWeight: 'bold' }}>AO VIVO</Text>}
              <Button title='Assistir' onPress={() => setSelectedGame(item)} />
            </View>
          )}
          keyExtractor={item => item.id}
        />
      )}
    </View>
  );
};

export default App;
